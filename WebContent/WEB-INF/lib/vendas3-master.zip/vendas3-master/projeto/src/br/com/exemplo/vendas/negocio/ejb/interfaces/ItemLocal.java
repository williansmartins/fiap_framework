package br.com.exemplo.vendas.negocio.ejb.interfaces ;

import javax.ejb.Local;

import br.com.exemplo.vendas.negocio.interfaces.ItemInterface;

@Local
public interface ItemLocal extends ItemInterface {
	
}