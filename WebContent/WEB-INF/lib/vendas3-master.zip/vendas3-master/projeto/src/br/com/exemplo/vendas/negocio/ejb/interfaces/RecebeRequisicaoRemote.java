package br.com.exemplo.vendas.negocio.ejb.interfaces ;

import javax.ejb.Remote ;

import br.com.exemplo.vendas.negocio.interfaces.RecebeRequisicaoInterface ;

@Remote
public interface RecebeRequisicaoRemote extends RecebeRequisicaoInterface {
	
}