package br.com.exemplo.vendas.util.dto ;

public class ServiceDTOException extends Throwable
{

	public ServiceDTOException( )
	{
	}

	public ServiceDTOException( String arg0 )
	{
		super( arg0 ) ;
	}
}
