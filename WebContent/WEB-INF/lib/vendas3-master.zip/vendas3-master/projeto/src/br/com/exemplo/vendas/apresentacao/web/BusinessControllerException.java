package br.com.exemplo.vendas.apresentacao.web ;

public class BusinessControllerException extends Exception
{
	public BusinessControllerException( )
	{
		super( ) ;
	}

	public BusinessControllerException( String arg0 )
	{
		super( arg0 ) ;
	}
}
