package br.com.exemplo.vendas.util.exception ;

public class TechnicalException extends SysException
{
	private static final long serialVersionUID = 1L ;
}