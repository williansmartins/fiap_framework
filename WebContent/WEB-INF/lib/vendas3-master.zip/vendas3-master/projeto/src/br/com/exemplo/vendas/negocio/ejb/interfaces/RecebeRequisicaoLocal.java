package br.com.exemplo.vendas.negocio.ejb.interfaces ;

import javax.ejb.Local ;

import br.com.exemplo.vendas.negocio.interfaces.RecebeRequisicaoInterface ;

@Local
public interface RecebeRequisicaoLocal extends RecebeRequisicaoInterface {
	
}