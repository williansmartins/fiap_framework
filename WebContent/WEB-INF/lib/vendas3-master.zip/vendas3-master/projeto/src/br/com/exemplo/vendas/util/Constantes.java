/**
 * 
 */
package br.com.exemplo.vendas.util;

/**
 * @author Alex
 *
 */
public class Constantes {

	public static final String MENSAGEM_FALHA_OPERACAO = "Desculpe, não foi possível processar sua solicitação. Tente novamente!";

	
	
}
